Contents:-
1.DelightMeter.html
2.DelightMeter.js
3.DelightMeterStyle.css
4.svgmeter.html

Authored by Sooraj Chandran on 24/4/2015
_______________________
HOW TO USE:
Change the range input to desired value to rotate the meter. 

_______________________
BROWSER SUPPORT:
Best viewed in Google Chrome
